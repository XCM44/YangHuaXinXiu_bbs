var that;
var app = getApp();
var api = require("../../api/api.js");//配置文件
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    that = this;
    api.Loading(this);    
    //登录判断
    var user = null;
    try {
      user = wx.getStorageSync('user');
    }
    catch (e) {
      user = getStorage('user');
    }
    if (user == null || !user) {
      wx.redirectTo({
        url: '/pages/login/login'
      });
      return;
    }
    
    else {
      
      this.setData({
        userInfo: user
      });
    }
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //渲染界面后 才显示
    api.UnLoading(this, 100);
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '扬华bbs',
      path: '/pages/index/index'
    }
  },
 
  /**
   * 用户信息设置
   */
  getUserInfo: function () {
    wx.navigateTo({
      url: '/pages/user/user_info'
    });
    return;
  },
  /**
   * 帮助中心
   */
  getHelp: function () {
    wx.navigateTo({
      url: '/pages/help/help'
    });
    return;
  },
  /**
   * 关于我们
   */
  getAboutUs: function () {
    wx.navigateTo({
      url: '/pages/aboutus/aboutus'
    });
    return;
  },
  //打电话
  calling: function (e) {
    var mobile = e.currentTarget.dataset.mobile;
    //拨打电话
    wx.makePhoneCall({
      phoneNumber: mobile, //需要拨打的电话号码
      success: function () {
        //接口调用成功的回调
      },
      fail: function () {
        //接口调用失败的回调函数
      }
    })
  },
  /**
   * 安全退出
   */
  getSafeExit: function () {
    try { 
      wx.removeStorageSync('user');
    }
    catch (e) {
      removeStorage('user');
    }
    wx.redirectTo({
      url: '/pages/index/index'
    });
    return;
  }
})