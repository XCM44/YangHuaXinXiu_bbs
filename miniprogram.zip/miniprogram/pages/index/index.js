var that;
var app = getApp();
var api = require("../../api/api.js"); //配置文件
Page({
  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [
      'https://m.roeshine.com/wechat_xcx/jingchangjizhang_ad01.png', 
      'https://m.roeshine.com/wechat_xcx/jingchangjizhang_ad02.png', 
      'https://m.roeshine.com/wechat_xcx/jingchangjizhang_ad03.png'
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 300
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    api.Loading(this);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    //渲染界面后 才显示
    api.UnLoading(this, 100);
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function(res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '扬华bbs',
      path: '/pages/index/index'
    }
  },
  goto_next: function (val) {
    wx.switchTab({
      url: '/pages/message/message'
    })
  }
})