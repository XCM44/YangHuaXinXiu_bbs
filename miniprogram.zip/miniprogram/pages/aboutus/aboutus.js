var that;
var app = getApp();
var api = require("../../api/api.js");//配置文件
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    actionSheetHidden: true,
    actionSheetItems: ['呼叫'],
    mobile: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    that = this;
    api.Loading(this);    
    //登录判断
    var user = null;
    try {
      user = wx.getStorageSync('user');
    }
    catch (e) {
      user = getStorage('user');
    }
    if (user == null || !user) {
      wx.redirectTo({
        url: '/pages/login/login'
      });
      return;
    }
    else {
      this.setData({
        userInfo: user
      });
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //渲染界面后 才显示
    api.UnLoading(this, 100);
  },
 
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '扬华bbs',
      path: '/pages/index/index'
    }
  },
  //打电话
  calling: function (e) {
    var mobile = e.currentTarget.dataset.mobile;
    //拨打电话
    wx.makePhoneCall({
      phoneNumber: mobile, //需要拨打的电话号码
      success: function () {
        //接口调用成功的回调
      },
      fail: function () {
        //接口调用失败的回调函数
      }
    })
  },
  //跳转地图
  gotoMap: function (e) {
    //获取当前的地理位置、速度。当用户离开小程序后，此接口无法调用；当用户点击“显示在聊天顶部”时，此接口可继续调用。
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        //使用微信内置地图查看位置
        wx.openLocation({
          latitude: 24.939478, //纬度，范围为-90~90，负数表示南纬
          longitude: 102.781089, //经度，范围为-180~180，负数表示西经
          name: "", //位置名
          address: "", //地址的详细说明
          scale: 215 //缩放比例，范围5~18，默认为18
        })
      }
    })
    return;
  },
  getAboutUs: function () {
    wx.showModal({
      title: '关于我们',
      content: '扬华bbs是一款基于美丽校园、失物招领、学习交流和跳蚤市场于一体的综合性校园服务平台。',
      showCancel: false
    })
  },
  bindActionSheet: function (e) {
    that = this;
    var tapIndex = e.currentTarget.dataset.index;
    if (tapIndex == 0) {
      // 呼叫号码
      wx.makePhoneCall({
        phoneNumber: that.data.mobile, //需要拨打的电话号码
        success: function () {
          //接口调用成功的回调
        },
        fail: function () {
          //接口调用失败的回调函数
        }
      })
    } else if (tapIndex == 1) {
     
    }
    this.setData({
      //取反
      actionSheetHidden: !this.data.actionSheetHidden
    })
  },
  listenerActionSheet: function () {
    this.setData({
      //取反
      actionSheetHidden: !this.data.actionSheetHidden
    })
  }
})