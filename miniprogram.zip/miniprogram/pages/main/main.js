const db=wx.cloud.database()
var that;
var app = getApp();
var api = require("../../api/api.js");//配置文件
var m;
var type=0;
var user = null;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataObj:"",
    casArray: ['美丽校园', '失物招领', '跳蚤市场', '学习交流'],
    casIndex: 0,
  },
  selectTap(){
    this.setData({
     show: !this.data.show
    });
    },
  getData(){
    db.collection("bbs").where({
      author:"zhurong"
    }).get().then(res=>{
    console.log(res)
      })
  },
  addData(){
    wx.showLoading({
      title: '数据加载中。。。',
      mask:true
    })
    db.collection("bbs").add({
      data:{
        title:"测试标题",
        author:"李四",
        content:"测试部分的内容测试部分的内容"
      }
    }).then(res=>{
      console.log(res)
      wx.hideLoading()
    })
  },
  // 获取用户头像和名称
  getinf(e){
    that = this;
    api.Loading(this);    
    //登录判断
    
    try {
      user = wx.getStorageSync('user');
    }
    catch (e) {
      user = getStorage('user');
    }
    if (user == null || !user) {
      wx.redirectTo({
        url: '/pages/login/login'
      });
      return;
    }
    
    else {
      
      this.setData({
        userInfo: user
      });
    }
  },
  exp(){
    console.log(type)
  },
  bindCasPickerChange: function (e) {
    console.log(e.detail.value)
    if (e.detail.value == 4) {
     this.setData({ reply: true })
    } else {
     this.setData({ reply: false })
    }
    type=e.detail.value
    this.setData({
     casIndex: e.detail.value
    })
  
   },

  optionTap(e){
    let  Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    type=Index
    console.log(Index)
    this.setData({
     index:Index,
     show:!this.data.show
    });
    },
  //提交表单添加进数据库
  btnSub(res){
    
    that = this;
    this.getinf();
    
    var resVlu=res.detail.value
    db.collection("bbs").add({
      data:{
        title:res.detail.value.title,
        type:type,
        content:res.detail.value.content,
        hits:0,
        author:user.nickName
      }
      
    }).then(res=>{
      console.log(res)

    })
    
    wx.switchTab({
      url: "/pages/message/message",
    })
  },
 
})
