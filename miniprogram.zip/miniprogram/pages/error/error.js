// error.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    msg: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      msg: options.msg
    })
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '扬华bbs',
      path: '/pages/index/index'
    }
  },
  
  /**
   * 返回用户中心
  */
  getBack: function () {
    wx.reLaunch({
      url: '/pages/index/index'
    })
    return;
  }
})