var that;
var app = getApp();
var api = require("../../api/api.js");//配置文件
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null,
    openId: '',
    access_token: '',
    userMobile: '',
    userPassWord: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    that = this;
    api.Loading(this);    
    //登录判断
    var user = null;
    try {
      user = wx.getStorageSync('user');
    }
    catch (e) {
      user = getStorage('user');
    }
    //console.log(user)
    if (user != null && user) {
      wx.switchTab({
        url: '/pages/main/main'
      });
      return;
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //渲染界面后 才显示
    api.UnLoading(this, 100);
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '扬华bbs',
      path: '/pages/index/index'
    }
  },
  // 获取输入手机号码
  userMobileInput: function (e) {
    this.setData({
      userMobile: e.detail.value
    })
  },
  // 获取输入密码
  userPassWordInput: function (e) {
    this.setData({
      userPassWord: e.detail.value
    });
  },
  GetUserInfo: function (e) {
    //console.log(e)
    if (that.data.userMobile.length <= 0) {
      wx.showModal({
        title: '错误',
        content: '请输入手机号码',
        showCancel: false
      });
      return;
    }

    if (that.data.userPassWord.length <= 0) {
      wx.showModal({
        title: '错误',
        content: '请输入密码',
        showCancel: false
      });
      return;
    }

    if (e.detail.errMsg != 'getUserInfo:ok') {
      wx.showModal({
        title: '请授权',
        content: '您需要授权后才能使用该小程序',
        showCancel: false
      });
      return;
    }
    
    wx.showLoading({
      title: '登录中',
      mask: true
    });

    wx.login({
      success: function (loginRes) {
        console.log('获取登录CODE', loginRes)
        if (loginRes.code.length <= 0) {
          wx.hideLoading();
          app.error('获取登录CODE发生异常');
          return false;
        }
        that.SubmitLogin(app, loginRes.code, that.LoginSuccess);//服务端登录
      },
      fail: function () {
        if (loginRes.code) {
          wx.hideLoading();
          app.error('获取登录CODE发生错误');
          return false;
        }
      }//fail end
    });
  },
  SubmitLogin: function (app, jscode, success) {
    //console.log('SubmitLogin', "")
    wx.getUserInfo({
      success: function (infoRes) {
        wx.hideLoading();
        //console.log('infoRes', infoRes)        
        var nickName = infoRes.userInfo.nickName
        var avatarUrl = infoRes.userInfo.avatarUrl
        var gender = infoRes.userInfo.gender //性别 0：未知、1：男、2：女
        var province = infoRes.userInfo.province
        var city = infoRes.userInfo.city
        var country = infoRes.userInfo.country

        //创建用户对象
        var user = {};

        user.timespan = new Date().getTime();
        user.avatarUrl = avatarUrl;
        user.nickName = nickName;
        user.gender = gender;
        user.province = province;
        user.city = city;
        user.country = country;

        //同步设置缓存
        try{
          wx.setStorageSync('user', user);
        }
        catch(e)
        {
          setStorage('user', user);
        }

        typeof success === "function" && success(user);

        //console.log('setStorageSync', user)

        wx.switchTab({
          url: '/pages/message/message'
        });
        return;
      },
      fail: function () {
        wx.hideLoading();
        wx.showModal({
          title: '提示',
          content: '您必须通过授权才能使用该小程序',
          showCancel: false,
          confirmText: '授权',
          success: function () {
            return;
          }
        });
      }
    })
  },
  /**
   * 打开同一公众号下关联的另一个小程序
   */
  ToMiniProgram: function () {
    wx.navigateToMiniProgram({
      appId: 'wxba56463ac2331695', //要打开的小程序 appId
      path: 'pages/index/index', //打开的页面路径，如果为空则打开首页
      extraData: {
        source: '扬华bbs' //在 App.onLaunch()，App.onShow() 中可接收该数据
      },
      envVersion: 'release', //有效值 develop（开发版），trial（体验版），release（正式版）
      success(res) {
        // 打开成功
      }
    })
  },
  /**
   * 用户注册
   */
  getRegister: function () {
    wx.redirectTo({
      url: '/pages/register/register'
    });
  }
})