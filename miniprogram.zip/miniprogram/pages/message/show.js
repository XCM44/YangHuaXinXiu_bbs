var that;
var app = getApp();
var api = require("../../api/api.js");//配置文件
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (e) {
    that = this;
    api.Loading(this);
    //登录判断
    var user = null;
    try {
      user = wx.getStorageSync('user');
    }
    catch (e) {
      user = getStorage('user');
    }
    if (user == null || !user) {
      wx.redirectTo({
        url: '/pages/login/login'
      });
      return;
    }
    else {
      this.setData({
        userInfo: user
      });
    }
    
    if (e.guid == null || !e.guid || e.guid == "") {
      wx.showModal({
        title: '错误',
        content: '参数出错！',
        showCancel: false,
        success: function (res) {
          if (res.confirm) {
            wx.navigateBack({})
          }
        }
      });
      return;
    }
    else {
      //post
      var _data = {
        guid: e.guid
      }
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    //渲染界面后 才显示
    api.UnLoading(this, 100);
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '扬华bbs',
      path: '/pages/index/index'
    }
  }
})