/**
 * 表单校验逻辑
 */

// 表单校验规则
const validators = {
  required: {
    rule: /.+/,
    msg: '必填项不能为空！'
  },
  name: {
    rule: /^[\u4e00-\u9fa5]{2,4}$/,
    msg: '请输入正确的名称！'
  },
  mobile: {
    rule: /^[\d]{11}$/,
    msg: '请输入正确的手机号码！'
  },
  tel: {
    rule: /^(\d{2}-)?(\d{3,4}-)?\d{7,8}$/,
    msg: '请输入正确的电话号码！'
  },
  password: {
    rule: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,18}$/,
    msg: '请输入6-18位字母和数字组成的密码！'
  },
  code: {
    rule: /^\d{4}$/,
    msg: '请输入正确的验证码！'
  },
  same: {
    rule (val='', sVal='') {
      return val===this.data[sVal]
    },
    msg: '两次输入不一致！'
  },
  zh: {
    rule: /^[\u4e00-\u9fa5]{0,}$/,
    msg: '请输入中文！'
  },
  email: {
    rule: /^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/,
    msg: '请输入正确的邮箱地址！'
  },
  num: {
    rule: /^(\d+[\s,]*)+\.?\d*$/,
    msg: '请输入正确的数值！'
  },
  money: {
    rule: /^([\u0024\u00A2\u00A3\u00A4\u20AC\u00A5\u20B1\20B9\uFFE5]\s*)(\d+,?)+\.?\d*\s*$/,
    msg: '请输入正确的货币金额！'
  },
  idcard: {
    rule: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
    msg: '请输入正确的身份证号码！'
  },
  ipv4: {
    rule: /^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})$/,
    msg: '请输入正确的IP地址！'
  },
  ipv6: {
    rule: /^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/,
    msg: '请输入正确的IPv6地址！'
  },
  qq: {
    rule: /^[1-9][0-9]{5,10}$/,
    msg: '请输入正确的QQ号码！'
  },
  wechat: {
    rule: /^[a-zA-Z\d_]{5,}$/,
    msg: '请输入正确的微信号！'
  },
  date: {
    rule: /^(?:(?:1[6-9]|[2-9][0-9])[0-9]{2}([-/.]?)(?:(?:0?[1-9]|1[0-2])\1(?:0?[1-9]|1[0-9]|2[0-8])|(?:0?[13-9]|1[0-2])\1(?:29|30)|(?:0?[13578]|1[02])\1(?:31))|(?:(?:1[6-9]|[2-9][0-9])(?:0[48]|[2468][048]|[13579][26])|(?:16|[2468][048]|[3579][26])00)([-/.]?)0?2\2(?:29))(\s+([01][0-9]:|2[0-3]:)?[0-5][0-9]:[0-5][0-9])?$/,
    msg: '请输入正确的(时间/日期)！'
  }
}
/**
 * 表单校验函数
 * 例子：
 * <input data-name="required" bindblur="validate">
 */
let validate = (e, context) => {
  let form = context.data.form || {}
  let name = e.currentTarget.dataset.name
  let value = (e.detail.value || '').trim()
  let validator = e.currentTarget.dataset.validator ? e.currentTarget.dataset.validator .split(',') : []
  if (name) {
    for (let i = 0; i < validator.length; i++) {
      let ruleName = validator[i].split('=')[0]
      let ruleValue = validator[i].split('=')[1]
      let rule = validators[ruleName].rule || /.*/
      if ('function' === typeof rule) {
        form[name] = rule.call(context, value, ruleValue) ? '' : validators[ruleName].msg
      } else {
        form[name] = rule.test(value) ? '' : validators[ruleName].msg
      }
      context.setData({
        form: form
      })
      if (form[name]) break;
    }
    form.$dirty = true
    form.$invalidMsg = ''
    for( let p in form) {
      if(p!=='$invalidMsg' && p!=='$dirty') form.$invalidMsg = form[p].trim() ? form[p] : form.$invalidMsg
    }
    context.setData({
      form
    })
  } else {
    console.error('缺少name属性值或validator属性值不合法')
  }
}
/**
 * 校验必填项是否为空
 * validateRequired(['phone', 'code'])
 */
let validateRequired = (properties, context) => {
  let form = context.data.form
  properties.forEach((item) => {
    if(!validators.required.rule.test(context.data[item] || '')) form[item] = validators.required.msg
  })
  form.$dirty = true
  form.$invalidMsg = ''
  for (let p in form) {
    if (p !== '$invalidMsg' && p !== '$dirty') form.$invalidMsg = form[p].trim() ? form[p] : form.$invalidMsg
  }
  context.setData({
    form
  })
}

module.exports = {
  validate,
  validateRequired
}