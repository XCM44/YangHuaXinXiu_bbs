var APPID ='wx55aa9978464bfa2a';
var SECRET ='428b0693d55b7e4b03db2cdad5c97047';

//判断用户输入的是否为小写字母
var regLowerCase = new RegExp('[a-z]', 'g');
//判断用户输入的是否为大写字母
var regCapitalLetter = new RegExp('[A-Z]', 'g');
//判断用户输入的是否为数字
var regNum = new RegExp('[0-9]', 'g');

var formatNumber = function (n) {
  return ('' + n)[1] ? n : '0' + n;
};
var formatTime = function (t) {
  const year = t.getFullYear();
  return t.getFullYear() + '年' + formatNumber(t.getMonth() + 1) + '月' + formatNumber(t.getDate()) + '日 ' + formatNumber(t.getHours()) + ':' + formatNumber(t.getMinutes()) + ':' + formatNumber(t.getSeconds());
};

var formatTime2 = function (t) {
  const year = t.getFullYear();
  return t.getFullYear() + '-' + formatNumber(t.getMonth() + 1) + '-' + formatNumber(t.getDate()) + ' ' + formatNumber(t.getHours()) + ':' + formatNumber(t.getMinutes());
};

var formatTime3 = function (t) {
  const year = t.getFullYear();
  return t.getFullYear() + '-' + formatNumber(t.getMonth() + 1) + '-' + formatNumber(t.getDate());
};

module.exports = {
  APPID: APPID,
  SECRET: SECRET,
  regLowerCase: regLowerCase,
  regCapitalLetter: regCapitalLetter,
  regNum: regNum,
  PostRequest: PostRequest,
  formatTime: formatTime,
  formatTime2: formatTime2,
  formatTime3: formatTime3,
  Loading: Loading,//显示加载中
  UnLoading: UnLoading//隐藏加载中
}

//通用Post请求
function PostRequest(action, data, success, fail, complete) {
  var url = "https://www.jingchangjizhang.com/webApi/system_json.ashx";
  data.action = action;
  wx.request({
    url: url,
    data: data,
    method: 'POST',
    header: {
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
    },
    success: function (res) {
      if (success != null) {
        success(res);
        return;
      }
    },
    fail: function (res) {
      console.log('请求失败', res);
      if (fail != null) {
        fail(res);
        return;
      } else {
        wx.reLaunch({
          url: '/pages/error/error?msg=' + '请求失败',
        })
        return;
      }
    },
    complete: function (res) {
      if (complete != null) {
        complete(res);
        return;
      }
    }
  })
}

/*===========渲染加载页===========*/
function Loading(that) {
  that.setData({
    loading: true
  });
}

function UnLoading(that, time = 500) {
  setTimeout(function () {
    that.setData({
      loading: false
    })
  }, time)
}
